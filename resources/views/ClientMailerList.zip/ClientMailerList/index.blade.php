@extends("layouts.panel")
{{-- @include('ClientModal.modal') --}}
@section('content')
    <style>
        ::-webkit-scrollbar {
            /* width: px; */
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background-color: navy;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #888;
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: #5556;
        }

        table.dataTable th,
        table.dataTable td {
            white-space: nowrap;
        }

        tbody {
            border-right: 1px solid #ccc;
            border-left: 1px solid #ccc;
        }

        thead {
            border-right: 1px solid #ccc;
            border-left: 1px solid #ccc;
        }

        .pagination>li>a,
        .pagination>li>span {
            position: relative;
            float: left;
            padding: 6px 12px;
            margin-left: -1px;
            line-height: 1.42857143;
            color: #337ab7;
            text-decoration: none;
            background-color: #fff;
            border: 1px solid #ddd;
        }

        .pagination>.active>a,
        .pagination>.active>a:focus,
        .pagination>.active>a:hover,
        .pagination>.active>span,
        .pagination>.active>span:focus,
        .pagination>.active>span:hover {
            z-index: 2;
            color: #fff;
            cursor: default;
            background-color: #337ab7;
            border-color: #337ab7;
        }

        .pagination>.disabled>a,
        .pagination>.disabled>a:focus,
        .pagination>.disabled>a:hover,
        .pagination>.disabled>span,
        .pagination>.disabled>span:focus,
        .pagination>.disabled>span:hover {
            color: #777;
            cursor: not-allowed;
            background-color: #fff;
            border-color: #ddd;
        }

        .dropdown-menu.show {
            padding-left: 10px;
        }

    </style>
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header card" id="grv_margin">
            <div class="row first_row_margin">
                <div class="col-lg-4">
                    <div class="page-header-title">
                        <i class="fas fa-rupee-sign mr-2"></i>
                        <h5> Client Mailer List</h5>
                        <p class="heading_Bottom">All Client Mailer Details Are Here</p>
                    </div>
                </div>

                <div class="col-lg-8">
                    <div class="buttons" style="text-align:right;margin:4px;">

                        <a href="{{ url(url('BillDetail/create')) }}"><button type="button" class="btn btn-success btn_new"
                                style="margin-bottom: -29px;"> <i class="fas fa-plus"> </i> Add
                                New</button></a>
                    </div>
                </div>
            </div>

            <div class="container-fluid bg-white mt-2 mb-5 border_radius box">
                <div class="row">
                    <div class="col-md-12 mt-3 mb-3">


                        <div class="container-fluid">
                            <form action="" method="GET" id="user-search" >
                                @csrf
                                <div class="row">
                                    <div class="col-md-12 mt-3 mb-3">
        
                                        <div class="container-fluid mt-3">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label for="client_id">Bill Id</label>
                                                    <fieldset>
                                                        <div class="input-group client_margin">
                                                            <span class="input-group-addon bg-primary border-primary white"
                                                                id="basic-addon7"
                                                                style="width: 43px;display: flex;justify-content: center;align-items: center;font-size: 23px;color: white;background-color: #4f81a4 !important;border: #4f81a4;"><i
                                                                    class="fas fa-briefcase"></i></span>
                                                            <input type="text" name="bill_id" value="{{ Request::get('bill_id') }}" class="form-control" id="file_no">
        
        
                                                        </div>
                                                    </fieldset>
                                                </div>
                                                
                                                <div class="col-md-3"><label for="client_name" style="margin-bottom: 0px">Client Name</label>
                                                    <select name="client" class="client" id="">
                                                        <option value="">Select</option>
                                                    </select>
                                                </div>
        

                                               <div class="col-md-2"><label for="from_date">From Date</label>
                                                <fieldset>
                                                    <div class="input-group client_margin">
                                                        <span class="input-group-addon bg-primary border-primary white"
                                                            id="basic-addon7"
                                                            style="width: 43px;display: flex;justify-content: center;align-items: center;font-size: 23px;color: white;background-color: #4f81a4 !important;border: #4f81a4;"><i
                                                                class="fas fa-briefcase"></i></span>
                                                        <input type="text" name="from_date" class="datepicker form-control" id="from_date"
                                                            value="{{ Request::get('from_date') ? Request::get('from_date') : date('Y-m-d') }}">
        
        
                                                    </div>
                                                </fieldset>
                                            </div>
                                            <div class="col-md-2"><label for="to_date">To Date</label>
                                                <fieldset>
                                                    <div class="input-group client_margin">
                                                        <span class="input-group-addon bg-primary border-primary white"
                                                            id="basic-addon7"
                                                            style="width: 43px;display: flex;justify-content: center;align-items: center;font-size: 23px;color: white;background-color: #4f81a4 !important;border: #4f81a4;"><i
                                                                class="fas fa-briefcase"></i></span>
                                                        <input type="text" name="to_date" class="datepicker form-control" id="to_date"
                                                            value="{{ Request::get('to_date') ? Request::get('to_date') : date('Y-m-d') }}">
        
        
                                                    </div>
                                                </fieldset>
                                            </div>
        
                                                <div class="col-md-2 mb-3  mt-3 px-3">
                                                    <input type="submit" name="find" value="find" class="btn btn-success">
                                                    <input type="submit" name="export_to_excel" value="Export To Csv" class="btn btn-primary">
        
                                                </div>
        
        
                                            </div>
                            </form>
                 
                    </div>

                    {{-- <hr class="border-dark bold">
                    <div class="container-fluid">
                        <div id="hide_2">
                            <div id="toolbar">
                                <select class="form-control ">
                                    <option value="">Export Basic</option>
                                    <option value="all">Export All</option>
                                    <option value="selected">Export Selected</option>
                                </select>
                            </div>

                            <table id="table" data-toggle="table" data-search="true" data-filter-control="true"
                                data-show-export="true" data-show-refresh="true" data-show-toggle="true"
                                data-pagination="true" data-toolbar="#toolbar">
                                <thead>
                                    <tr>



                                        <th data-field="examen223" data-sortable="true">Id</th>
                                        <th data-field="examenw223" data-sortable="true">Bill no</th>
                                        <th data-field="examen44" data-sortable="true">Client Id</th>
                                        <th data-field="examen434" data-sortable="true">Client</th>


                                        <th data-field="examen2" data-sortable="true">Billing Date</th>
                                        <th data-field="examen" data-sortable="true">Month</th>
                                        <th data-field="exameen" data-sortable="true">Plant</th>
                                        <th data-field="examen33" data-sortable="true">Amount</th>
                                        <th data-field="examen242" data-sortable="true">Paid Amount</th>
                                        <th data-field="examen22" data-sortable="true">Pending Amount</th>

                                        <th data-field="note13" data-sortable="true">Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @foreach ($bills as $bill)
                                        @php
                                            $client_id = enCrypt($bill->client_id);
                                            $encrypt_id = enCrypt($bill->id);
                                        @endphp
                                        <tr>
                                            <td><a href='{{ url("custombill/$encrypt_id") }}'
                                                    class="text-primary">{{ $bill->char_id }}</a></td>

                                            <td><a href='#'
                                                    class="text-primary">{{ $bill->bill_no }}</a></td>

                                            <td><a href='{{ url("clientpdf/{$client_id}") }}'
                                                    class="text-primary">{{ $bill->client_char_id }}</a></td>
                                            <td>
                                                {{ $bill->client_name }}


                                            </td>

                                            <td>{{ date('d-m-Y' , strtotime($bill->billing_date)) }}</td>
                                            <td>{{ $bill->month }}</td>

                                            <td>
                                              {{$bill->plant_name}}
                                            </td>
                                            <td>{{ round($bill->amount,2) }}</td>
                                            <td>{{ round($bill->paid_amount,2) }}</td>
                                            <td>{{ round($bill->pending_amount,2) }}</td>





                                            <td><span class="dropdown open">
                                                    <button id="btnGroup" type="button" data-toggle="dropdown"
                                                        aria-haspopup="true" aria-expanded="true"
                                                        class="btn btn-primary btn-sm dropdown-toggle dropdown-menu-right">
                                                        <i class="fas fa-cog"></i>
                                                    </button>
                                                    <span aria-labelledby="btnGroup"
                                                        class="dropdown-menu mt-1 dropdown-menu-right">


                                                        <a href='{{ url("downloadbill/$encrypt_id") }}'
                                                            style="font-weight:300; font-size:15px "><i
                                                                class="fas fa-download"></i>Download</a> <br> 
                                                        <a href='{{ route('BillDetail.edit', $encrypt_id) }}'
                                                            style="font-weight:300 ; font-size:15px "><i
                                                                class="fas fa-pencil-alt"></i>Edit </a><br>

                                                        <a  href='{{ url("regeneratebill/$encrypt_id") }}' style="font-weight:300 ; font-size:15px"><i class="fas fa-refresh"></i>Regenerate Bill</a><br> 

                                                        {{-- <form action="" method="GET" class="blockuie dropdown-item">
                                                        @csrf
                                                        <input type="text"  name="route" hidden
                                                            value="{{ 'regeneratebill' }}">
                                                        <input type="text" id="delete_id"  name="id" hidden
                                                            value="{{  $encrypt_id}}">
                                                        <button style="background:none;border: none; margin-left:-25px; margin-bottom:-11px;"
                                                            type="button" onclick="confirMationAlert1()"><i
                                                                class="fas fa-refresh"
                                                                 ></i> Regenerate Bill</button>
                                                    </form> --}}

                                                     
                                                        {{-- <form action="{{ route('BillDetail.destroy', $encrypt_id) }}" method="POST" class="blockuie">
                                                            @csrf
                                                            @method('delete')
                                                            <button type="submit" style="background:none;border: none; font-weight:300; margin-left:-5px"><i class="fas fa-trash"></i>Cancel Bill</button>
                                                        </form> --}}
                                    
                                </tbody>
                            </table> 


                        </div>

                        <!-- Close Row -->
                    </div>
                    <!-- Close Container -->
                </div>
            </div>
        </div>
    @endsection
